from django.apps import AppConfig


class BeltAppConfig(AppConfig):
    name = 'belt_app'
